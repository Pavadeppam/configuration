const data = require('./data.json');

function filterHotels(filters, data) {
  const { maxGuest, rooms, themes, facilities, priceRange } = filters;

  return data.filter((hotel) => {
    //   console.log('priceRange', priceRange);
    // Filter by maxGuest
    if (maxGuest && hotel.maxGuest !== maxGuest) {
      return false;
    }

    // Filter by rooms
    if (rooms && hotel.rooms !== rooms) {
      return false;
    }

    // Themes filter
    if (themes && themes.length > 0) {
      const hasAllThemes = themes.every((theme) =>
        hotel.themes.includes(theme)
      );
      if (!hasAllThemes) {
        console.log('facilities', facilities);
        return false;
      }
    }

    // Facility filter
    if (facilities && facilities.length > 0) {
      const hasAllThemes = facilities.every((facility) => {
        return hotel.facilities.map((item) => item.title).includes(facility);
      });
      if (!hasAllThemes) {
        return false;
      }
    }

    // Filter by priceRange
    if (priceRange && (priceRange.lowRange || priceRange.highRange)) {
      const { lowRange, highRange } = priceRange;
      const villaPrice = hotel.villaprice.amount;

      if (lowRange && villaPrice < lowRange) {
        return false;
      }
      if (highRange && villaPrice > highRange) {
        return false;
      }
    }

    return true;
  });
}

// const filters = {
//   maxGuest: 4,
//   rooms: 2,
//   themes: ['Luxury', 'Beachfront'],
//   facilities: ['ACTIVITIES', 'HOTEL'],
//   priceRange: {
//     lowRange: 2000,
//     highRange: 8500,
//   },
// };
const filters = {
  maxGuest: '',
  rooms: '',
  themes: [],
  facilities: [],
  priceRange: {
    lowRange: 1000,
    highRange: 9000,
  },
};

// 1 apply filter
const filteredHotels = filterHotels(filters, data.data.destinationResponse);

// 2 extract BookByVilla tab data
const bookByVillaData = filteredHotels.filter(
  (item) => item.bookentirevillatab
);

// 2.1 build unique BooKVilla themes
// Extract the 'themes' property and create a Set
const uniqueThemesV = new Set(bookByVillaData.map((item) => item.themes));

// Convert the Set back to an array if needed
const uniqueThemesDataV = [...uniqueThemesV];

// Flatten the array
const uniqueThemesDataFacetV = uniqueThemesDataV.flat();

// Convert the flattened array to a Set to get unique values
const uniqueThemesDataFacetValuesV = new Set(uniqueThemesDataFacetV);

// Convert the Set back to an array if needed
const booKByVillaThemesV = Array.from(uniqueThemesDataFacetValuesV);

// 2.2 build unique BooKVilla Facilities

// Extract the 'themes' property and create a Set
const uniqueFacilitiesV = new Set(
  bookByVillaData.map((item) => item.facilities)
);

// Convert the Set back to an array if needed
const uniqueFacilitiesDataV = [...uniqueFacilitiesV];

// Flatten the array
const uniqueFacilitiesDataFacetV = uniqueFacilitiesDataV.flat();

//Extract the facilities values from each object
const uniqueFacilitiesArrayV = uniqueFacilitiesDataFacetV.map(
  (obj) => obj.title
);

//Convert the facility values to a Set to remove duplicates
const uniqueFacilitiesFacetV = new Set(uniqueFacilitiesArrayV);

// Convert the Set back to an array if needed
const bookByVillaFacilitiesV = Array.from(uniqueFacilitiesFacetV);

// 2.3 build final BookVilla tab data along with tab level facet
const bookByVillaTab = {
  data: bookByVillaData,
  facets: {
    facilities: bookByVillaFacilitiesV,
    themes: booKByVillaThemesV,
  },
};

// 3 extract BookByRoom tab data
const bookByRoomData = filteredHotels.filter((item) => item.bookbyroomtab);

// console.log(bookByRoomData);

// 3.1 build unique BooKVilla themes
// Extract the 'themes' property and create a Set
const uniqueThemesR = new Set(bookByRoomData.map((item) => item.themes));

// Convert the Set back to an array if needed
const uniqueThemesDataR = [...uniqueThemesR];

// Flatten the array
const uniqueThemesDataFacetR = uniqueThemesDataR.flat();

// Convert the flattened array to a Set to get unique values
const uniqueThemesDataFacetValuesR = new Set(uniqueThemesDataFacetR);

// Convert the Set back to an array if needed
const booKByVillaThemesR = Array.from(uniqueThemesDataFacetValuesR);

// 3.2 build unique BooKVilla Facilities

// Extract the 'themes' property and create a Set
const uniqueFacilitiesR = new Set(
  bookByRoomData.map((item) => item.facilities)
);

// Convert the Set back to an array if needed
const uniqueFacilitiesDataR = [...uniqueFacilitiesR];

// Flatten the array
const uniqueFacilitiesDataFacetR = uniqueFacilitiesDataR.flat();

//Extract the facilities values from each object
const uniqueFacilitiesArrayR = uniqueFacilitiesDataFacetR.map(
  (obj) => obj.title
);

//Convert the facility values to a Set to remove duplicates
const uniqueFacilitiesFacetR = new Set(uniqueFacilitiesArrayR);

// Convert the Set back to an array if needed
const bookByVillaFacilitiesR = Array.from(uniqueFacilitiesFacetR);

// 3.3 build final BookVilla tab data along with tab level facet
const bookByRoomTab = {
  data: bookByRoomData,
  facets: {
    facilities: bookByVillaFacilitiesR,
    themes: booKByVillaThemesR,
  },
};

console.log(bookByRoomTab);
