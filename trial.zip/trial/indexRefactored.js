const data = require('./data.json');
const filter = require('./filter.js');

function filterHotels(filters, data) {
  const { maxGuest, rooms, themes, facilities, priceRange } = filters;

  return data.filter((hotel) => {
    // if (!hotel.themes || hotel.themes.length === 0) return false; // Filter out hotels with undefined or empty themes
    if (maxGuest && hotel.maxGuest !== maxGuest) return false;
    if (rooms && hotel.rooms !== rooms) return false;
    if (themes && !themes.every((theme) => hotel.themes.includes(theme)))
      return false;
    if (
      facilities &&
      !facilities.every((facility) =>
        hotel.facilities.map((item) => item.title).includes(facility)
      )
    )
      return false;
    if (priceRange && (priceRange.lowRange || priceRange.highRange)) {
      const { lowRange, highRange } = priceRange;
      const villaPrice = hotel.villaprice.amount;
      if (lowRange && villaPrice < lowRange) return false;
      if (highRange && villaPrice > highRange) return false;
    }
    return true;
  });
}

function extractUniqueThemes(data) {
  const themes = data.map((item) => item.themes).filter(Boolean); // Filter out undefined values
  const uniqueThemes = new Set(themes.flat());
  return Array.from(uniqueThemes);
}

function extractUniqueFacilities(data) {
  const facilities = data.map((item) => item.facilities).filter(Boolean); // Filter out undefined values
  const facilityTitles = facilities.flatMap((facility) =>
    facility.map((item) => item.title)
  );
  const uniqueFacilities = new Set(facilityTitles);
  return Array.from(uniqueFacilities);
}

const filteredHotels = filterHotels(filter, data.data.destinationResponse);

const bookByVillaData = filteredHotels.filter(
  (item) => item.bookentirevillatab
);
const bookByVillaThemes = extractUniqueThemes(bookByVillaData);
const bookByVillaFacilities = extractUniqueFacilities(bookByVillaData);

const bookByRoomData = filteredHotels.filter((item) => item.bookbyroomtab);
const bookByRoomThemes = extractUniqueThemes(bookByRoomData);
const bookByRoomFacilities = extractUniqueFacilities(bookByRoomData);

const bookByVillaTab = {
  bookByVillaTab: bookByVillaData,
  facets: {
    facilities: bookByVillaFacilities,
    themes: bookByVillaThemes,
  },
};

const bookByRoomTab = {
  bookByRoomTab: bookByRoomData,
  facets: {
    facilities: bookByRoomFacilities,
    themes: bookByRoomThemes,
  },
};

console.log(bookByVillaTab);
console.log('*************************************************************');
console.log(bookByRoomTab);
