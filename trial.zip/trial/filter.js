const filter = {
  maxGuest: '',
  rooms: '',
  themes: [],
  facilities: [],
  priceRange: {
    lowRange: 2000,
    highRange: 5000,
  },
};

module.exports = filter;
